package data.services;

import data.datasource.cart.CartDataSource;
import data.datasource.catalog.CatalogDataSource;
import data.datasource.order.OrderDataSource;
import data.models.CartItem;
import data.models.Order;
import data.models.Product;

import java.util.ArrayList;

public class ShopService {
    final CartDataSource cartDataSource;
    final CatalogDataSource catalogDataSource;
    final OrderDataSource orderDataSource;


    // Создаем конструктор для ShopService
    public ShopService(CartDataSource cartDataSource, CatalogDataSource catalogDataSource, OrderDataSource orderDataSource) {
        this.cartDataSource = cartDataSource;
        this.catalogDataSource = catalogDataSource;
        this.orderDataSource = orderDataSource;
    }

    // Пишем метод getCatalog(), чтобы возвращать каталог продуктов
    public ArrayList<Product> getCatalog(){
        return catalogDataSource.getCatalog();
    }

    // Создаем метод addToCart(), чтобы добавлять продукты в корзину
    public boolean addToCart(String productId, int count){
        ArrayList<Product> products = getCatalog();
        for (Product p : products) {
            if(p.id.equals(productId)){
                cartDataSource.addToCart(p, count);
                return true;
            }
        }
        return false;
    }

    //Прописываем метод getCart(), чтобы возвращать список продуктов из корзины
    public ArrayList<CartItem> getCart(){
        return cartDataSource.getCart();
    }

    //Создаем метод createOrder(), чтобы создавать заказы
    public void createOrder(String name, String phone, String address,
                            String paymentType, String deliveryTime){
        ArrayList<CartItem> cart = getCart();
        Order order = new Order(name, phone, address, paymentType, deliveryTime, cart);
        orderDataSource.createOrder(order);
    }
}
