package data.models;

public class CartItem {
    // Создаем класс CartItem для модели корзины
        public final Product product;
        public final int count;


        // Прописываем конструктор для CartItem
        public CartItem(Product product, int count) {
            this.product = product;
            this.count = count;
        }
    }
