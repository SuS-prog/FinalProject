package data.models;

public class Product {
    // Создаем класс Product для моделей продуктов
    public final String id;
    public final String title;
    public final String description;
    public final int price;
    public final boolean available;


    // Прописываем конструктор для Product
    public Product(String id, String title, String description, int price, boolean available) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.price = price;
        this.available = available;
    }
}
