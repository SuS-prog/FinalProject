package data.datasource.cart;

import data.models.CartItem;
import data.models.Product;

import java.util.ArrayList;

public class MockCartDataSource extends CartDataSource{
    private ArrayList<CartItem> cart = new ArrayList<>();

    // Добавляем метод addToCart() для добавления продуктов в корзину
    @Override
    public void addToCart(Product product, int count) {
        cart.add(new CartItem(product, count));
    }

    // Возвращаем нашу корзину
    @Override
    public ArrayList<CartItem> getCart() {
        return cart;
    }
}
