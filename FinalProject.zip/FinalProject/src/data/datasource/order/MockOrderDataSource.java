package data.datasource.order;

import data.models.Order;

public class MockOrderDataSource extends OrderDataSource{
    private Order order;

    //Создаем заказ
    @Override
    public void createOrder(Order order) {
        this.order = order;
    }

    // Получаем заказ
    @Override
    public Order getOrder() {
        return order;
    }
}
