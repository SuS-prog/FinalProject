package view;

import common.AppView;
import data.services.ShopService;

import java.util.ArrayList;
import java.util.Scanner;

public class OrderView extends AppView {
    final ShopService shopService;


    // Создаем конструктор для OrderView
    public OrderView(ShopService shopService) {
        super("Ordering", new ArrayList<>());
        this.shopService = shopService;
    }

    // Прописываем метод action() для OrderView, чтобы принимать значения во время заказа
    @Override
    public void action() {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter your name: ");
        String name = in.nextLine();
        System.out.println("Enter your phone: ");
        String phone = in.nextLine();
        shopService.createOrder(name, phone, "address", "МИР", "any time");
    }

}
