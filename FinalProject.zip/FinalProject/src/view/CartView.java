package view;

import common.AppView;
import data.models.CartItem;
import data.services.ShopService;

import java.util.ArrayList;

public class CartView extends AppView {
    final ShopService shopService;

    //Прописываем конструктор для CartView()
    public CartView(ShopService shopService) {
        super("Cart", new ArrayList<>());
        this.shopService = shopService;
    }

    // Создаем метод action() для CartView, чтобы выводить список продуктов из корзины
    @Override
    public void action() {
        ArrayList<CartItem> cart = shopService.getCart();
        for(CartItem item : cart){
            System.out.println(item.product.id + " " + item.product.title + " " + item.product.price);
        }
        System.out.println();
    }
}
