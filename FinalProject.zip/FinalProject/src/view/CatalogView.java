package view;

import common.AppView;
import data.models.Product;
import data.services.ShopService;

import java.util.ArrayList;

public class CatalogView extends AppView {
    final ShopService shopService;

    // Создаем конструктор для CatalogView
    public CatalogView(ShopService shopService, ArrayList<AppView> children) {
        super("Catalog", children);
        this.shopService = shopService;
    }

    // Пишем метод action() для CatalogView, чтобы выводить каталог продуктов
    @Override
    public void action() {
        ArrayList<Product> catalog = shopService.getCatalog();
        for(Product p : catalog){
            System.out.println(p.id + " " + p.title + " " + p.price);
        }
        System.out.println();
    }
}
