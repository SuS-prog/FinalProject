package view;

import common.AppView;
import data.services.ShopService;

import java.util.ArrayList;
import java.util.Scanner;

public class AddToCartView extends AppView {
    final ShopService shopService;

    // Создаем конструктор AddToCartView()
    public AddToCartView(ShopService shopService) {
        super("Add to cart", new ArrayList<>());
        this.shopService = shopService;
    }

    // Создаем метод action(), чтобы принимаь значения от пользователя(id, name, count и т.д.)
    // И выводим "Success" в случае успеха или "Fail" в случае неудачи
    @Override
    public void action() {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter product id: ");
        String productId = in.nextLine();
        if(productId == null){
            return;
        }
        System.out.println("Enter count: ");
        int count = in.nextInt();
        final boolean res = shopService.addToCart(productId, count);
        if(res){
            System.out.println("Success");
        } else{
            System.out.println("Fail");
        }
    }
}
