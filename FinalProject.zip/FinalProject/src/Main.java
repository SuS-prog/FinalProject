import common.AppView;
import common.PageLoop;
import data.datasource.cart.CartDataSource;
import data.datasource.cart.MockCartDataSource;
import data.datasource.catalog.CatalogDataSource;
import data.datasource.catalog.MockCatalogDataSource;
import data.datasource.order.MockOrderDataSource;
import data.datasource.order.OrderDataSource;
import data.services.ShopService;
import view.*;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
       // Создаем объекты(catalogDataSource, cartDataSource, orderDataSource и shopService)
       CatalogDataSource catalogDataSource = new MockCatalogDataSource();
       CartDataSource cartDataSource = new MockCartDataSource();
       OrderDataSource orderDataSource = new MockOrderDataSource();
       ShopService shopService = new ShopService(cartDataSource, catalogDataSource, orderDataSource);

       //Создаем странички
       AppView addToCartView = new AddToCartView(shopService);
       ArrayList<AppView> catalogChildren = new ArrayList<>();
       catalogChildren.add(addToCartView);

       //Создаем каталог
       AppView catalogView = new CatalogView(shopService, catalogChildren);

       //Создаем корзину
       AppView cartView = new CartView(shopService);

       //Создаем заказ
       AppView orderView = new OrderView(shopService);

       // Сщздаем пункты основного меню
       ArrayList<AppView> mainChildren = new ArrayList<>();
       mainChildren.add(catalogView);
       mainChildren.add(cartView);
       mainChildren.add(orderView);

       AppView mainView = new MainView(mainChildren);
       // Запускаем проект
       new PageLoop(mainView).run();
       
    }
}
