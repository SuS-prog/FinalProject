package common;

import java.util.Scanner;

public class PageLoop {
    final AppView view;
    public PageLoop(AppView view) {
        this.view = view;
    }

    //Создаем метод run() для запуска нашей программы
    public void run(){
        while(true){
            view.action();
            displayChildren();
            Scanner in = new Scanner(System.in);
            int value = in.nextInt();
            if(value < 0 || value > view.children.size()+1){
                System.out.println("Wrong value");
            } else if (value == view.children.size()+1) {
                break;
            } else {
                AppView selectedView = view.children.get(value-1);
                new PageLoop(selectedView).run();
            }
        }
    }

    //Создаем метод displayChildren(), чтобы выводить выбор от 1 до последнего числа в списке
    void displayChildren(){
        System.out.println(view.title);
        System.out.println("Choose from 1 to " + (view.children.size() + 1) + "");
        for (int i = 0; i < view.children.size(); i++) {
            AppView vview = view.children.get(i);
            System.out.println(i + 1 + " - " + vview.title);
        }
        System.out.println(view.children.size()+ 1 + " - Back");
    }


}
